Modified dygraph.js library to allow easy translation of the month abbreviation labels.
Modifications are at lines 6310-6315
Uses the SHORT_MONTH_NAMES_CUSTOM var to set the month abbreviations (if this is set)
 (this needs to be set before including the modified dygraph.js script)