Resources
=========

* `conquest`: Conquest PACS lua files.
* `doc`: dwv doc resources.
* `help`: dwv help resources. The touch icons are modified versions of a theme set by P.J. Onori found on [icon finder](https://www.iconfinder.com/iconsets/cue).
* `icons`: dwv icons.
* `img`: misc images.
* `module`: javascript module scripts.
* `scripts`: apps and update scripts.
