<?php
// This script was removed by patch. Can find this script here:
//  https://github.com/openemr/openemr/blob/rel-500/setup.php
?>
